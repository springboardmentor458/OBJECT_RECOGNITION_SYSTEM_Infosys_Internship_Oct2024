import streamlit as st
import cv2
import numpy as np
from PIL import Image
from io import BytesIO
import base64
from ultralytics import YOLO

# Load the YOLO model
model = YOLO("yolov8n.pt")  # Make sure to have the YOLO model file in the same directory

# Function to process images
def process_image(image):
    results = model(image)
    annotated_image = results[0].plot()
    return annotated_image

# Function to process videos
def process_video(video_file):
    cap = cv2.VideoCapture(video_file)
    frames = []
    while cap.isOpened():
        ret, frame = cap.read()
        if not ret:
            break
        results = model(frame)
        annotated_frame = results[0].plot()
        frames.append(annotated_frame)
    cap.release()
    return frames

# Convert image to base64 string
def pil_to_base64(pil_image):
    buffered = BytesIO()
    pil_image.save(buffered, format="PNG")
    return base64.b64encode(buffered.getvalue()).decode()

# Streamlit UI
st.title("YOLO Object Recognition App")

# Custom CSS for styling
st.markdown("""
    <style>
        body {
            background-color: #f4f7f6;
            font-family: 'Arial', sans-serif;
            margin: 0;
            padding: 0;
            display: flex;
            height: 100vh;
        }
        
        /* Sidebar Styling */
        .css-1d391kg {
            background-color: #2c3e50;
            color: white;
            padding: 20px;
            width: 250px;
            height: 100vh;
            position: fixed;
        }

        .css-1d391kg .sidebar-content {
            display: flex;
            flex-direction: column;
            justify-content: start;
        }
        
        /* Header and Navigation Links */
        .sidebar-content .sidebar-header {
            font-size: 24px;
            font-weight: bold;
            margin-bottom: 30px;
            color: #ffffff;
        }
        
        /* Styling for the large buttons */
        .css-1d391kg .sidebar-content .stButton button {
            background-color: #34495e;
            color: white;
            padding: 16px 30px;
            font-size: 18px;
            font-weight: bold;
            border-radius: 8px;
            border: none;
            cursor: pointer;
            margin-bottom: 15px;
            text-align: left;
            transition: background-color 0.3s, transform 0.2s;
        }

        .css-1d391kg .sidebar-content .stButton button:hover {
            background-color: #1abc9c;
            transform: scale(1.05);
        }

        /* Styling for the dropdowns */
        .stSelectbox, .stMultiselect {
            font-size: 18px;
            font-weight: bold;
            padding: 12px;
            background-color: #34495e;
            color: white;
            border-radius: 8px;
            border: none;
            margin-bottom: 20px;
            transition: background-color 0.3s;
        }

        .stSelectbox:hover, .stMultiselect:hover {
            background-color: #1abc9c;
        }

        /* Main Content Area */
        .main-content {
            flex-grow: 1;
            padding: 20px;
            margin-left: 270px;  /* Offset for sidebar */
            background-color: white;
            box-shadow: 0px 4px 6px rgba(0, 0, 0, 0.1);
            border-radius: 10px;
        }

        /* Header Styling */
        h1 {
            font-size: 2.5em;
            text-align: center;
            color: #333;
            margin-bottom: 30px;
        }

        /* Image & Video Display */
        .image-container {
            display: flex;
            justify-content: center;
            margin-top: 20px;
        }

        .image-container img {
            max-width: 100%;
            height: auto;
            border: 2px solid #ddd;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
        }

    </style>
""", unsafe_allow_html=True)

# Sidebar Navigation with large labels and dropdown
st.sidebar.header("Navigation")
nav_choice = st.sidebar.selectbox("Select Option", ["Upload Image", "Upload Video", "Real-time Camera"])

# Main content based on navigation choice
if nav_choice == "Upload Image":
    st.sidebar.subheader("Upload Image")
    uploaded_image = st.sidebar.file_uploader("Upload an image...", type=["jpg", "jpeg", "png"])
    if uploaded_image is not None:
        image = np.array(Image.open(uploaded_image))
        annotated_image = process_image(image)
        annotated_image_pil = Image.fromarray(annotated_image)
        base64_image = pil_to_base64(annotated_image_pil)
        st.markdown(f'<div class="image-container"><img src="data:image/png;base64,{base64_image}" /></div>', unsafe_allow_html=True)

elif nav_choice == "Upload Video":
    st.sidebar.subheader("Upload Video")
    uploaded_video = st.sidebar.file_uploader("Upload a video file", type=["mp4", "mov", "avi", "mkv"])
    if uploaded_video is not None:
        video_bytes = uploaded_video.read()
        with open("temp_video.mp4", "wb") as f:
            f.write(video_bytes)
        frames = process_video("temp_video.mp4")
        for frame in frames:
            st.image(frame, channels="BGR", use_column_width=True)

elif nav_choice == "Real-time Camera":
    st.sidebar.subheader("Real-time Camera Feed")
    enable_camera = st.sidebar.button("Start Camera")
    if enable_camera:
        st.write("Starting camera...")
        cap = cv2.VideoCapture(0)

        # Create a placeholder for the video feed
        frame_placeholder = st.empty()

        while True:
            ret, frame = cap.read()
            if not ret:
                break
            results = model(frame)
            annotated_frame = results[0].plot()

            # Display the annotated frame in the placeholder
            frame_placeholder.image(annotated_frame, channels="BGR", use_column_width=True)

        cap.release()
