from flask import Flask, request, render_template, send_file, Response
from ultralytics import YOLO
import cv2
import numpy as np
from PIL import Image
import io
import os

app = Flask(__name__)
app.config['UPLOAD_FOLDER'] = 'static/uploads/'

# Initialize YOLO model
class Detection:
    def __init__(self):
        self.model = YOLO("yolov8n.pt")  # Replace with the path to your YOLO weights

    def predict_and_draw(self, image):
        results = self.model(image)
        for result in results:
            for box in result.boxes:
                x1, y1, x2, y2 = map(int, box.xyxy[0])
                label = result.names[int(box.cls[0])]
                conf = box.conf[0]
                cv2.rectangle(image, (x1, y1), (x2, y2), (0, 255, 0), 2)
                cv2.putText(image, f"{label} {conf:.2f}", (x1, y1 - 10),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 1)
        return image


detector = Detection()


@app.route('/')
def index():
    return render_template('index.html')


@app.route('/object-detection', methods=['POST'])
def object_detection():
    if 'image' not in request.files:
        return 'No file part'
    file = request.files['image']

    if file.filename == '':
        return 'No selected file'

    filepath = os.path.join(app.config['UPLOAD_FOLDER'], file.filename)
    file.save(filepath)

    image = cv2.imread(filepath)
    image = cv2.resize(image, (640, 640))
    result_img = detector.predict_and_draw(image)

    # Convert result to bytes
    _, img_encoded = cv2.imencode('.png', result_img)
    img_bytes = io.BytesIO(img_encoded)

    os.remove(filepath)  # Cleanup the uploaded image
    return send_file(img_bytes, mimetype='image/png')


@app.route('/video')
def video_page():
    return render_template('video.html')


def gen_frames():
    cap = cv2.VideoCapture(0)
    while cap.isOpened():
        ret, frame = cap.read()
        if not ret:
            break

        frame = cv2.resize(frame, (640, 640))
        result_frame = detector.predict_and_draw(frame)

        _, buffer = cv2.imencode('.jpg', result_frame)
        yield (b'--frame\r\n'
               b'Content-Type: image/jpeg\r\n\r\n' + buffer.tobytes() + b'\r\n')


@app.route('/video_feed')
def video_feed():
    return Response(gen_frames(), mimetype='multipart/x-mixed-replace; boundary=frame')


if __name__ == '__main__':
    app.run(debug=True)
